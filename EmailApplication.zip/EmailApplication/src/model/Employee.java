package model;

public class Employee
{
    private static String fname;
    private static String lname;
    Employee(String fname,String lname)
    {
        super();
        Employee.fname = fname;
        Employee.lname = lname;
    }
    public void setFname(String fname) {
        Employee.fname = fname;
    }
    public void setLname(String lname) {
        Employee.lname = lname;
    }
    public static String getFname() 
    {
        return fname;
    }
    public static String getLname() 
    {
        return lname;
    }
}