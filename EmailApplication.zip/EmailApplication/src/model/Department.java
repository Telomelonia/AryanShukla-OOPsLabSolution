package model;

public class Department {
    private static String deptname;
    Department(String deptname)
    {
        super();
        Department.deptname = deptname;

    }
    public void setDeptname(String deptname) {
        Department.deptname = deptname;
    }
    public static String getDeptname() {
        return deptname;
    }
}
