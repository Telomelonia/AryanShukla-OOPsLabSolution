package model;
import static model.Service.Password;

import java.util.*;
public class Main {
    public static void main(String[] args) {        
        Employee emp = new Employee("krish", "tyson");
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Please enter the department from the following");
        System.out.println("1.Technical");
        System.out.println("2.Admin");
        System.out.println("3.Human Resource");
        System.out.println("4.Legal");
        int key = sc.nextInt();
        System.out.println("Dear "+emp.getFname()+" your generated credentials are as follows");
        switch (key) 
        {
            case 1:
                Department tech = new Department("tech");   
                System.out.println("Email_ID   :"+Service.EmailId());
                System.out.println("Password    :"+Service.Password());        
                break;
            case 2:
                Department admin = new Department("admin");
                System.out.println("Email_ID   :"+Service.EmailId());
                System.out.println("Password    :"+Service.Password());
                break;
            case 3:
                Department HR = new Department("hr");
                System.out.println("Email_ID   :"+Service.EmailId());
                System.out.println("Password    :"+Service.Password());
                break;
            
            case 4:
                Department legal = new Department("legal");
                System.out.println("Email_ID   :"+Service.EmailId());
                System.out.println("Password    :"+Service.Password());
                break;
            default:
                System.out.println("Error input");
                break;
        }
    }

}
